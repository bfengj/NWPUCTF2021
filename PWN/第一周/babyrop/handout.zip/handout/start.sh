#/bin/bash
cd challenge/
timeout 30 ./babyrop
