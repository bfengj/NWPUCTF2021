window.onload=function(){
var fw=document.getElementById('fw');
var liclass=document.getElementById('liclass');
	fw.onmousemove=function(){
		liclass.style.display="block";
		} 
	liclass.onmousemove=function(){
		liclass.style.display="block";
		} 	
	liclass.onmouseout=function(){
		liclass.style.display="none";
		} 

}