<?php
$DB_HOST='';
$DB_USER='';
$DB_PWD='';
$DB_NAME='';
?>
